/* ========================================
   Configuração do Sistema
   ======================================== */

window.APP_CONFIG = {
    // Supabase (cliente)
    SUPABASE_URL: 'https://waoinjpwdhdjhiybjuue.supabase.co',
    SUPABASE_ANON_KEY: 'sb_publishable_JJtIwq3rBLyzX5wuEXpZaA_ygN_m6Wx',

    // Google Calendar API - PREENCHER com suas chaves (ver README e módulo Calendar)
    GOOGLE_CLIENT_ID: '', // ex: '1234567890-abcdef.apps.googleusercontent.com'
    GOOGLE_API_KEY: '',   // ex: 'AIzaSy...'
    GOOGLE_DISCOVERY_DOC: 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest',
    GOOGLE_SCOPES: 'https://www.googleapis.com/auth/calendar',

    // App
    APP_NAME: 'Central de Gestão',
    APP_VERSION: '2.0',
    USE_SUPABASE: true,       // false = modo demo fixo
    USE_DEMO_FALLBACK: true,  // se Supabase falhar, usa dados demo em memória
};

// A inicialização real do Supabase acontece no app.js (após DOMContentLoaded)
// porque o script @supabase/supabase-js precisa terminar de carregar primeiro.
